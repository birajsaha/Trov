﻿using System.Data;
using System.Linq;
using NUnit.Framework;
using Trov;

namespace TrovTest
{
    [TestFixture]
    public class ItemPurchaseTest
    {
        [Test]
        public void Valid()
        {
            var entities = new TestModel().Entities;
            const string name = "Plane";
            new ItemPurchase { Entities = entities, Name = name }.Run();
            Assert.IsFalse(entities.Items.Any(i => name == i.Name));
        }

        [Test]
        public void Invalid()
        {
            var entities = new TestModel().Entities;
            const string name = "PlaneX";
            Assert.Throws<RowNotInTableException>(() => new ItemPurchase { Entities = entities, Name = name }.Run());
        }
    }
}
