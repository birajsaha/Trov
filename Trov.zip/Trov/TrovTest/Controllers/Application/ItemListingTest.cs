﻿using System.Linq;
using Newtonsoft.Json;
using NUnit.Framework;
using Trov;

namespace TrovTest
{
    [TestFixture]
    public class ItemListingTest
    {
        [Test]
        public void Items()
        {
            Assert.AreEqual(
                "[" +
                "{\"Name\":\"Car\",\"Description\":\"Fancy Car\",\"Price\":60000}," +
                "{\"Name\":\"Plane\",\"Description\":\"Fancy Plane\",\"Price\":5000000}," +
                "{\"Name\":\"Ring\",\"Description\":\"Fancy Ring\",\"Price\":30000}" +
                "]",
                JsonConvert.SerializeObject(
                    new ItemListing { Entities = new TestModel().Entities }.Items().OrderBy(i => i.Name).ToList()));
        }
    }
}