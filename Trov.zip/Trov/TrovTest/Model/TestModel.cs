﻿using Effort;
using Trov;

namespace TrovTest
{
    public class TestModel
    {
        public Entities Entities { get; }

        public TestModel()
        {
            Entities = new Entities(DbConnectionFactory.CreateTransient());
            Entities.Items.Add(
                new Item
                {
                    Name = "Car",
                    Description = "Fancy Car",
                    Price = 60000,
                });

            Entities.Items.Add(
                new Item
                {
                    Name = "Ring",
                    Description = "Fancy Ring",
                    Price = 30000,
                });

            Entities.Items.Add(
                new Item
                {
                    Name = "Plane",
                    Description = "Fancy Plane",
                    Price = 5000000,
                });

            Entities.SaveChanges();
        }
    }
}
