﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Web.Configuration;
using System.Web.Http;

namespace Trov
{
    [Authorize]
    public class ItemsController : ApiController
    {
        private readonly DbConnection dbConnection;
        private readonly Entities entities;

        public ItemsController()
        {
            var connectionString = WebConfigurationManager.AppSettings["DatabaseConnection"];
            var factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            this.dbConnection = factory.CreateConnection();
            // ReSharper disable once PossibleNullReferenceException
            this.dbConnection.ConnectionString = connectionString;
            this.entities = new Entities(this.dbConnection);
            this.entities.Database.Log = s => System.Diagnostics.Debug.WriteLine(s);
        }

        public IEnumerable<Item> GetAllItems()
        {
            return new ItemListing { Entities = this.entities }.Items();
        }

        [Route("api/purchase/{name}")]
        public IHttpActionResult GetItem(string name)
        {
            try
            {
                new ItemPurchase { Entities = this.entities, Name = name }.Run();
            }
            catch (RowNotInTableException)
            {
                return NotFound();
            }
            return Ok();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                try
                {
                    this.entities.Dispose();
                    this.dbConnection.Dispose();
                }
                catch (Exception e)
                {
                    System.Diagnostics.Debug.WriteLine(e);
                }
            }
            base.Dispose(disposing);
        }
    }
}