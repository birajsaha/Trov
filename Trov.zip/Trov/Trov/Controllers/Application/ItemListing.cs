﻿using System.Collections.Generic;

namespace Trov
{
    public class ItemListing
    {
        public Entities Entities { private get; set; }

        public IEnumerable<Item> Items()
        {
            return Entities.Items;
        }
    }
}
