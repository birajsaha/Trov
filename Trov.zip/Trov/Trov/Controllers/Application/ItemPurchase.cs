﻿using System.Data;
using System.Linq;

namespace Trov
{
    public class ItemPurchase
    {
        public Entities Entities { private get; set; }
        public string Name { private get; set; }

        public void Run()
        {
            var item = Entities.Items.FirstOrDefault(i => Name == i.Name);
            if (ReferenceEquals(null, item))
            {
                throw new RowNotInTableException();
            }
            Entities.Items.Remove(item);
            Entities.SaveChanges();
        }
    }
}
