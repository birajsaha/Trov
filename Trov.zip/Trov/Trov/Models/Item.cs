﻿using System.ComponentModel.DataAnnotations;

namespace Trov
{
    public class Item
    {
        [Required]
        [Key]
        [StringLength(255)]
        public string Name { get; set; }

        public string Description { get; set; }

        public int Price { get; set; }
    }
}
