﻿using System.Data.Common;
using System.Data.Entity;

namespace Trov
{
    public class Entities : DbContext
    {
        public Entities(DbConnection dbConnection)
            : base(dbConnection, false)
        {
            Configuration.AutoDetectChangesEnabled = false;
        }

        public virtual DbSet<Item> Items { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Item>()
                .Property(e => e.Name)
                .IsUnicode(false);
        }
    }
}
